            <div class="container-fluid">
                <div class="row">

                <!-- horizontal form -->
                <?php
                echo $confirmation;
                $attribute = array(
                    'name' => '',
                    'class' => 'form-horizontal',
                    'id' => ''
                );
                echo form_open_multipart('', $attribute);
                ?>

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="panal-header-title pull-left">
                                <h1>Create An Account</h1>
                            </div>
                        </div>

                        <div class="panel-body no-padding">

                        
                        <div class="no-title">&nbsp;</div>

                            <!-- left side -->
                            <aside class="col-md-3">
                                <!--div class="border-top">&nbsp;</div-->
                                
                                
                                <figure class="profile-pic">
                                    <img src="<?php echo site_url("private/images/pic-male.png"); ?>" alt="Photo not found!" class="img-responsive">
                                </figure>

                                <div class="profile-upload">    
                                    
                                    <label class="btn btn-primary" style="display: block;" for="image"><i class="fa fa-cloud-upload"></i> Upload</label>
                                    <input type="file" name="image" required id="image" style="display: none;">
                                </div> <br/>

                                <table class="table table-status">
                                    <tbody>
                                        <tr>
                                            <td style="width: 60%">Status</td>
                                            <td><span class="status">Active</span></td>
                                        </tr>
                                        <tr>
                                            <td style="width: 60%">User Rating</td>
                                            <td>
                                                <i class="fa fa-star co-yellow"></i>
                                                <i class="fa fa-star co-yellow"></i>
                                                <i class="fa fa-star co-yellow"></i>
                                                <i class="fa fa-star co-yellow"></i>
                                                <i class="fa fa-star co-yellow"></i>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 60%">Member Since</td>
                                            <td>June 07, 2016 </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </aside>


                            <div class="col-md-9">
                                    <div>
                                        <h3 style="margin-top:0;">Account Setting</h3>
                                    </div>
                                
                                
                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Email</label>
                                        <div class="col-md-7">
                                            <input type="email" name="email" class="form-control" placeholder="email@yourcompany.com">
                                        </div>

                                        <!--div class="col-md-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-globe"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Username</label>
                                        <div class="col-md-7">
                                            <input type="text" name="username" class="form-control" placeholder="username">
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-globe"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Password</label>
                                        <div class="col-md-7">
                                            <input class="form-control" type="password" name="password" placeholder="password">
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-globe"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Confirm Password</label>
                                        <div class="col-md-7">
                                            <input class="form-control" type="password" name="confirmPassword" placeholder="confirm password">
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-globe"></i></button>
                                        </div-->
                                    </div>

                                    <hr/>

                                    <!-- Profile Setting -->

                                    <h3 class="mgbt-20">Profile Setting</h3>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">First Name</label>
                                        <div class="col-md-7">
                                            <input class="form-control" type="text" name="f_name" placeholder="firstname">
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-globe"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Last Name</label>
                                        <div class="col-md-7">
                                             <input class="form-control" type="text" name="l_name" placeholder="lastname">
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-lock"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Gender</label>
                                        <div class="col-md-7">
                                            <label class="radio-button"> 
                                                <input type="radio" name="gender" value="male" checked> Male
                                            </label>
                                            &nbsp;&nbsp;
                                            <label class="radio-button">
                                                <input type="radio" name="gender" value="female"> Female
                                            </label>
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-lock"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Birthday</label>
                                        <div class="input-group date col-md-7" id="datetimepicker1"  >
    		                            <input type="text" name="birthday" class="form-control" />
    		                            <span class="input-group-addon">
    		                                <span class="glyphicon glyphicon-calendar"></span>
    		                            </span>
    		                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-user"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Marital Status</label>
                                        <div class="col-md-7">
                                            <select name="maritial_status" class="form-control">
                                                <option value="single">Single</option>
                                                <option value="marride">Marride</option>
                                            </select>
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-user"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Position</label>
                                        <div class="col-md-7">                                            
                                            <select name="position" class="form-control">
                                                <option value="">-- Select Position --</option>
                                                <option value="ceo">CEO</option>
                                                <option value="director">Director</option>
                                                <option value="manager">Manager</option>
                                                <option value="staff">Staff</option>
                                            </select>
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-user"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Privilege</label>
                                        <div class="col-md-7">
                                            <select name="privilege" class="form-control">
                                                <option value="">-- Select Privilege --</option>
                                                <!--option value="super">Super</option-->
                                                <option value="admin">Admin</option>
                                                <option value="user">User</option>
                                            </select>
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-user"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">About</label>
                                        <div class="col-md-7">
                                            <textarea name="about" class="form-control" cols="30" rows="4"></textarea>
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-globe"></i></button>
                                        </div-->
                                    </div>

                                    <hr/>

                                    <h3>Contact Setting</h3>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Mobile/ Phone</label>
                                        <div class="col-md-7">
                                            <input type="text" name="mobile" class="form-control" placeholder="mobile phone">
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-globe"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Website</label>
                                        <div class="col-md-7">
                                            <input type="text" name="website" class="form-control" placeholder="website">
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-globe"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Facebook</label>
                                        <div class="col-md-7">
                                            <input type="text" name="facecbook" class="form-control" placeholder="facebook">
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-globe"></i></button>
                                        </div-->
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="col-md-3 control-label">Twitter</label>
                                        <div class="col-md-7">
                                            <input type="text" name="twitter" class="form-control" placeholder="twitter">
                                        </div>

                                        <!--div class="col-sm-2 col-xs-2">
                                            <button class="btn-icon"><i class="fa fa-globe"></i></button>
                                        </div-->
                                    </div>

                                    
                                    <div class="form-group">
                                        <label class="col-md-3 control-label"></label>
                                        <div class="col-md-7">
                                            <div class="btn-group pull-right">
                                                <input class="btn btn-primary" type="submit" name="createProfileBtn" value="Save">
                                                <input class="btn btn-danger" type="reset" value="Clear">
                                            </div>
                                        </div>
                                        <!--div class="col-sm-2 col-xs-2"></div-->
                                    </div>
                            </div>
                        </div>

                        <div class="panel-footer">&nbsp;</div>
                    </div>

                    <?php echo form_close(); ?>
                </div>
            </div>

